import sqlite3
from datetime import datetime

def connect_with_db(func):
    def wrapper(*args, **kwargs):
        with sqlite3.connect('online_store.db') as conn:
            cursor = conn.cursor()
            result = func(cursor, *args, **kwargs)
            conn.commit()
            return result
    return wrapper

@connect_with_db
def register_user(cursor):
    username = input("Введите имя пользователя: ")
    password = input("Введите пароль: ")
    email = input("Введите email: ")
    address = input("Введите адрес: ")

    try:
        cursor.execute('''
            INSERT INTO users (username, password, email, address)
            VALUES (?, ?, ?, ?);
        ''', (username, password, email, address))
        print("Регистрация прошла успешно.")
    except sqlite3.IntegrityError:
        print("Ошибка: Пользователь с таким именем уже существует.")

@connect_with_db
def login_user(cursor):
    username = input("Введите имя пользователя: ")
    password = input("Введите пароль: ")

    cursor.execute('''
        SELECT id FROM users
        WHERE username = ? AND password = ?;
    ''', (username, password))

    user = cursor.fetchone()
    if user:
        print(f"Добро пожаловать, {username}!")
        return user[0]
    else:
        print("Неверное имя пользователя или пароль.")
        return None

@connect_with_db
def view_products(cursor):
    cursor.execute('SELECT * FROM products')
    products = cursor.fetchall()
    if products:
        for product in products:
            print(product)
    else:
        print("Нет доступных товаров.")

@connect_with_db
def add_to_cart(cursor, user_id):
    try:
        product_id = int(input("Введите ID товара: "))
        quantity = int(input("Введите количество: "))
    except ValueError:
        print("Ошибка: Введите корректное число.")
        return

    cursor.execute('''
        INSERT INTO cart (user_id, product_id, quantity)
        VALUES (?, ?, ?);
    ''', (user_id, product_id, quantity))

    print("Товар добавлен в корзину.")

@connect_with_db
def checkout(cursor, user_id):
    cursor.execute('SELECT * FROM cart WHERE user_id = ?', (user_id,))
    cart_items = cursor.fetchall()

    if not cart_items:
        print("Ваша корзина пуста.")
        return

    order_date = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    cursor.execute('''
        INSERT INTO orders (user_id, order_date, status)
        VALUES (?, ?, ?);
    ''', (user_id, order_date, 'Pending'))

    order_id = cursor.lastrowid

    for item in cart_items:
        cursor.execute('''
            INSERT INTO order_items (order_id, product_id, quantity)
            VALUES (?, ?, ?);
        ''', (order_id, item[2], item[3]))

    cursor.execute('DELETE FROM cart WHERE user_id = ?', (user_id,))
    print("Заказ оформлен. Спасибо за покупку!")

def main_menu():
    while True:
        print("\nМеню:")
        print("1. Регистрация")
        print("2. Вход")
        print("3. Просмотр товаров")
        print("4. Добавить товар в корзину")
        print("5. Оформить заказ")
        print("6. Выход")

        choice = input("Выберите действие (1/2/3/4/5/6): ")

        if choice == '1':
            register_user()
        elif choice == '2':
            user_id = login_user()
            if user_id:
                while True:
                    print("\nМеню пользователя:")
                    print("1. Просмотр товаров")
                    print("2. Добавить товар в корзину")
                    print("3. Оформить заказ")
                    print("4. Выйти")

                    user_choice = input("Выберите действие (1/2/3/4): ")

                    if user_choice == '1':
                        view_products()
                    elif user_choice == '2':
                        add_to_cart(user_id)
                    elif user_choice == '3':
                        checkout(user_id)
                    elif user_choice == '4':
                        break
                    else:
                        print("Неверный выбор. Попробуйте снова.")
        elif choice == '3':
            view_products()
        elif choice == '4':
            user_id = login_user()
            if user_id:
                add_to_cart(user_id)
        elif choice == '5':
            user_id = login_user()
            if user_id:
                checkout(user_id)
        elif choice == '6':
            print("Выход из программы.")
            break
        else:
            print("Неверный выбор. Попробуйте снова.")

if __name__ == "__main__":
    main_menu()
