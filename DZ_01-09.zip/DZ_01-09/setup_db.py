import sqlite3

def create_tables():
    with sqlite3.connect('online_store.db') as conn:
        cursor = conn.cursor()

        # Создание таблицы пользователей
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL,
                email TEXT,
                address TEXT
            )
        ''')

        # Создание таблицы товаров
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS products (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                description TEXT,
                price REAL NOT NULL,
                stock INTEGER NOT NULL
            )
        ''')

        # Создание таблицы заказов
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS orders (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                order_date TEXT NOT NULL,
                status TEXT NOT NULL,
                FOREIGN KEY (user_id) REFERENCES users (id)
            )
        ''')

        # Создание таблицы товаров в заказах
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS order_items (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                order_id INTEGER NOT NULL,
                product_id INTEGER NOT NULL,
                quantity INTEGER NOT NULL,
                FOREIGN KEY (order_id) REFERENCES orders (id),
                FOREIGN KEY (product_id) REFERENCES products (id)
            )
        ''')

        # Создание таблицы корзины
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS cart (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                product_id INTEGER NOT NULL,
                quantity INTEGER NOT NULL,
                FOREIGN KEY (user_id) REFERENCES users (id),
                FOREIGN KEY (product_id) REFERENCES products (id)
            )
        ''')

        print("Таблицы успешно созданы.")

def insert_sample_data():
    with sqlite3.connect('online_store.db') as conn:
        cursor = conn.cursor()

        products = [
            ('Ноутбук Asus ZenBook', 'Ноутбук', 899.99, 15),
            ('Ноутбук Dell XPS 13', 'Ноутбук', 1199.99, 10),
            ('Ноутбук Apple MacBook Pro', 'Ноутбук', 2299.99, 5),
            ('Компьютер для игр MSI', 'Компьютер', 1499.99, 8),
            ('Компьютер рабочий HP Elite', 'Компьютер', 799.99, 12),
            ('Компьютер сборка AMD Ryzen', 'Компьютер', 999.99, 7)
        ]

        cursor.executemany('''
            INSERT INTO products (name, description, price, stock)
            VALUES (?, ?, ?, ?);
        ''', products)

        conn.commit()
        print("Данные добавлены в таблицу products.")

if __name__ == "__main__":
    create_tables()
    insert_sample_data()
